# Reelsmith Remotion starter kit (v5)

A complete Remotion 4 project for beat-synced sizzles and narrated explainers in 16:9, 9:16 and 1:1, driven by the same `brand.json` as the HyperFrames templates.

    npm i
    python3 ../scripts/brand.py bundle ../brand/sample-brand.json --out public   # -> public/brand/ (logo, fonts, brand.resolved.json)
    npx tsx scripts/generate-voiceover.ts src/plans/featureExplainer.ts           # free: Kokoro if installed, else espeak
    npx tsc --noEmit
    npx remotion compositions        # Sizzle-*, SizzleVo-*, Explainer-*, FeatureExplainer-* (x3 aspects) + LottieDemo
    npx remotion render FeatureExplainer-9x16 out/fe-9x16.mp4 --scale=0.5 --crf=28   # draft for review
    python3 ../scripts/export.py loudnorm out/fe-9x16-full.mp4 out/fe-9x16.mp4       # master to -14 LUFS

- `src/plans/*.ts`: one Plan per video (bpm, music, scenes, optional voiceover, optional `brandFile`).
- Scene kinds: `kinetic`, `lower-third`, `logo`, `feature` (numbered card: `index`, `text`, `sub`), `stat` (`value` + label).
- `src/kit/brand.ts`: `themeFromBrand()` maps brand colors/fonts/logo onto the theme; `loadBrandFonts()` loads the bundled font files before rendering.
- `src/kit/`: theme, layout (`useLayout()` gives per-aspect safe areas), kinetic text, logo, lower third, feature card, stat callout, captions.
- `src/Sizzle/`: TransitionSeries timeline; `calculateMetadata.ts` measures VO files and loads `brandFile`. Scenes stretch to whole beats long enough for their narration.
- Narrated renders show a small "Narration: AI-generated voice" label (set `aiVoiceDisclosure: false` only for a real human voice).
- `scripts/generate-voiceover.ts <plan> [--dry-run]`: `TTS_PROVIDER=auto` (default) uses free local voices: Kokoro (via `hyperframes tts`, set `HYPERFRAMES_PYTHON` if needed), then espeak-ng. Paid voices (`elevenlabs`, `openai`, `polly`) are used only when you name them AND the key is in env; `REELSMITH_IGNORE_KEYS=1` forces free. `--dry-run` prints provider + character count and needs no key.
- `scripts/export-captions.ts <plan>`: writes word timings JSON for `scripts/captions.py build` (SRT/VTT/ASS).
- `src/LottieDemo.tsx` + `public/lottie/pulse.json`: minimal `@remotion/lottie` example.
- `public/music/demo-bed-120bpm.mp3`: a synthetic 120 BPM bed generated with ffmpeg, free to use. Swap in a licensed track and its beat grid (see references/music-sources.md).

Remotion does not normalize loudness; always run `export.py loudnorm` (or `export.py run` after review) on the final file.

Needs Node 20.19+ or 22.13+. Remotion is free for individuals and teams of up to 3; larger companies need a license (remotion.pro/license).

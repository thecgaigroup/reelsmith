/**
 * Export the rendered video's word timings as one words.json (absolute times), for SRT/VTT sidecars:
 *   npx tsx scripts/export-captions.ts src/plans/<slug>.ts > out/<slug>.words.json
 *   python3 <reelsmith>/scripts/captions.py build --words out/<slug>.words.json -o out/<slug> --aspect 16x9
 * Scene i starts at the sum of earlier scene lengths (TransitionSeries overlaps each outgoing transition),
 * using the same rule as src/Sizzle/calculateMetadata.ts: max(beats, VO + 0.4s) rounded up to whole beats.
 */
import { existsSync, readFileSync } from "node:fs";
import path from "node:path";
import { pathToFileURL } from "node:url";
import type { Plan, VoManifest } from "../src/plans/types";

const FPS = 30;
const PAD_SECONDS = 0.4;

const main = async () => {
  const planName = process.argv[2];
  if (!planName) throw new Error("Usage: export-captions.ts src/plans/<slug>.ts");
  const planPath = planName.includes("/") ? path.resolve(planName) : path.resolve("src/plans", planName);
  const mod = (await import(pathToFileURL(planPath).href)) as Record<string, Plan>;
  const plan = Object.values(mod)[0];
  const manifestPath = path.join("public", "vo", plan.slug, "manifest.json");
  if (!existsSync(manifestPath)) throw new Error(`${manifestPath} missing: run scripts/generate-voiceover.ts first`);
  const vo = (JSON.parse(readFileSync(manifestPath, "utf8")) as VoManifest).scenes;
  const fpb = (60 / plan.bpm) * FPS;
  let start = 0;
  const words: { text: string; startMs: number; endMs: number }[] = [];
  plan.scenes.forEach((scene, i) => {
    const v = vo[i];
    const voFrames = v?.durationInSeconds ? Math.ceil(v.durationInSeconds * FPS) : 0;
    const planned = scene.beats * fpb;
    const frames = voFrames ? Math.round(Math.max(planned, Math.ceil((voFrames + PAD_SECONDS * FPS) / fpb) * fpb)) : Math.round(planned);
    const offsetMs = (start / FPS) * 1000;
    for (const c of v?.captions ?? []) words.push({ text: c.text, startMs: Math.round(c.startMs + offsetMs), endMs: Math.round(c.endMs + offsetMs) });
    start += frames;
  });
  process.stdout.write(JSON.stringify({ slug: plan.slug, fps: FPS, durationMs: Math.round((start / FPS) * 1000), words }, null, 2));
};

main().catch((e: unknown) => {
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
});

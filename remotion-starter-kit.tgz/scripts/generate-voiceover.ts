/**
 * Generate one voiceover clip per scene + word captions + manifest.
 *   npx tsx scripts/generate-voiceover.ts src/plans/<slug>.ts [--dry-run]   (a bare plan name also works)
 * env: TTS_PROVIDER=auto (default) | kokoro | local | elevenlabs | openai
 *   auto    -> free voices only: Kokoro (via `npx hyperframes tts`, needs HYPERFRAMES_PYTHON with kokoro-onnx) then espeak-ng.
 *   kokoro  -> free, local, natural-sounding. TTS_VOICE (default af_heart).
 *   local   -> espeak-ng scratch track for timing previews.
 *   elevenlabs | openai -> PAID. Used only when named explicitly; needs ELEVENLABS_API_KEY + TTS_VOICE_ID or OPENAI_API_KEY.
 * Never logs keys or voice IDs. --dry-run prints the character count only (no API calls).
 */
import { execFileSync } from "node:child_process";
import { mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { ALL_FORMATS, FilePathSource, Input } from "mediabunny";
import type { Caption } from "../src/kit/CaptionTrack";
import type { Plan, VoManifest } from "../src/plans/types";

const [planName, flag] = process.argv.slice(2);
if (!planName) throw new Error("Usage: generate-voiceover.ts <plan-name> [--dry-run]");
const dryRun = flag === "--dry-run";
const requested = process.env.TTS_PROVIDER ?? "auto";
const voiceId = process.env.TTS_VOICE_ID ?? "";

const need = (name: string) => {
  const v = process.env[name];
  if (!v) throw new Error(`${name} is not set`); // name only, never the value
  return v;
};

const wordsFromChars = (chars: string[], starts: number[], ends: number[]): Caption[] => {
  const out: Caption[] = [];
  let cur: Caption | null = null;
  chars.forEach((ch, i) => {
    if (/\s/.test(ch)) {
      if (cur) out.push(cur);
      cur = null;
      return;
    }
    if (!cur) cur = { text: "", startMs: starts[i] * 1000, endMs: ends[i] * 1000 };
    cur.text += ch;
    cur.endMs = ends[i] * 1000;
  });
  if (cur) out.push(cur);
  return out;
};

// Fallback word timings when the provider returns none: spread over the clip, weighted by word length
// (+ a small pause after punctuation). Good enough for captions; use ElevenLabs alignment or a transcriber for exact timing.
const evenCaptions = (text: string, seconds: number): Caption[] => {
  const words = text.split(/\s+/).filter(Boolean);
  const weight = (w: string) => w.replace(/[^\p{L}\p{N}]/gu, "").length + 2 + (/[,.;:!?]$/.test(w) ? 3 : 0);
  const total = words.reduce((n, w) => n + weight(w), 0);
  const lead = 80, tail = 120; // ms of silence most engines add
  const span = Math.max(seconds * 1000 - lead - tail, 100);
  let t = lead;
  return words.map((w) => {
    const d = (weight(w) / total) * span;
    const c = { text: w, startMs: Math.round(t), endMs: Math.round(t + d) };
    t += d;
    return c;
  });
};

const duration = async (file: string) => {
  const input = new Input({ formats: ALL_FORMATS, source: new FilePathSource(file) });
  try {
    return await input.computeDuration();
  } finally {
    input.dispose();
  }
};

// Retries rate limits and server errors; 4xx auth/validation errors fail fast.
const post = async (url: string, init: RequestInit) => {
  for (let attempt = 1; ; attempt++) {
    const res = await fetch(url, init);
    if ((res.status === 429 || res.status >= 500) && attempt < 4) {
      await new Promise((r) => setTimeout(r, 2000 * attempt));
      continue;
    }
    return res;
  }
};

const elevenlabs = async (text: string, previous_text?: string, next_text?: string): Promise<{ audio: Buffer; captions: Caption[] | null }> => {
  const res = await post(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}/with-timestamps`, {
    method: "POST",
    headers: { "xi-api-key": need("ELEVENLABS_API_KEY"), "Content-Type": "application/json" },
    body: JSON.stringify({
      text,
      previous_text, // context for consistent prosody across per-scene clips
      next_text,
      model_id: process.env.TTS_MODEL ?? "eleven_multilingual_v2",
      voice_settings: { stability: 0.5, similarity_boost: 0.75, style: 0.3 },
    }),
  });
  if (!res.ok) throw new Error(`ElevenLabs ${res.status}: ${(await res.text()).slice(0, 300)}`);
  const json = (await res.json()) as {
    audio_base64: string;
    alignment?: { characters: string[]; character_start_times_seconds: number[]; character_end_times_seconds: number[] };
  };
  const a = json.alignment;
  return {
    audio: Buffer.from(json.audio_base64, "base64"),
    captions: a ? wordsFromChars(a.characters, a.character_start_times_seconds, a.character_end_times_seconds) : null,
  };
};

const openai = async (text: string): Promise<{ audio: Buffer; captions: Caption[] | null }> => {
  const res = await post("https://api.openai.com/v1/audio/speech", {
    method: "POST",
    headers: { Authorization: `Bearer ${need("OPENAI_API_KEY")}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.TTS_MODEL ?? "gpt-4o-mini-tts",
      voice: voiceId || "cedar",
      input: text,
      instructions: process.env.TTS_INSTRUCTIONS ?? "Confident, warm, energetic promo read.",
      response_format: "mp3",
    }),
  });
  if (!res.ok) throw new Error(`OpenAI ${res.status}: ${(await res.text()).slice(0, 300)}`);
  return { audio: Buffer.from(await res.arrayBuffer()), captions: null };
};

// Robotic but free: use for a timing preview before spending TTS credits.
const local = async (text: string): Promise<{ audio: Buffer; captions: Caption[] | null }> => {
  const wav = path.join(os.tmpdir(), `vo-${Date.now()}.wav`);
  const mp3 = wav.replace(/\.wav$/, ".mp3");
  execFileSync("espeak-ng", ["-s", "165", "-w", wav, text]);
  execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-i", wav, "-ar", "44100", "-b:a", "128k", mp3]);
  const audio = readFileSync(mp3);
  rmSync(wav);
  rmSync(mp3);
  return { audio, captions: null };
};

// Free, local neural voice through the HyperFrames CLI (Kokoro-82M, Apache-2.0).
const hfCmd = () => (process.env.HF_CMD ?? "npx --yes hyperframes@0.8.188").split(" ");
const kokoro = async (text: string): Promise<{ audio: Buffer; captions: Caption[] | null }> => {
  const wav = path.join(os.tmpdir(), `vo-k-${Date.now()}.wav`);
  const mp3 = wav.replace(/\.wav$/, ".mp3");
  const [bin, ...args] = hfCmd();
  execFileSync(bin, [...args, "tts", text, "-o", wav, "--voice", process.env.TTS_VOICE ?? "af_heart"], { stdio: ["ignore", "ignore", "pipe"] });
  execFileSync("ffmpeg", ["-y", "-loglevel", "error", "-i", wav, "-ar", "44100", "-b:a", "160k", mp3]);
  const audio = readFileSync(mp3);
  rmSync(wav);
  rmSync(mp3);
  return { audio, captions: null };
};

const has = (cmd: string, args: string[]) => {
  try {
    execFileSync(cmd, args, { stdio: "ignore" });
    return true;
  } catch {
    return false;
  }
};

// auto never picks a paid provider. Paid ones must be requested by name AND have their key set.
const pickProvider = (): string => {
  if (requested === "elevenlabs" || requested === "openai") {
    const key = requested === "elevenlabs" ? "ELEVENLABS_API_KEY" : "OPENAI_API_KEY";
    if (!process.env[key] || process.env.REELSMITH_IGNORE_KEYS === "1") {
      console.warn(`${requested} requested but ${key} is not set; falling back to free voices.`);
    } else return requested;
  }
  if (requested === "local") return "local";
  if (requested === "kokoro" || requested === "auto" || requested === "elevenlabs" || requested === "openai") {
    if (process.env.HYPERFRAMES_PYTHON && has(process.env.HYPERFRAMES_PYTHON, ["-c", "import kokoro_onnx"])) return "kokoro";
    if (requested === "kokoro") console.warn("Kokoro unavailable (set HYPERFRAMES_PYTHON to a python with kokoro-onnx); using espeak-ng.");
  }
  return "local";
};

const main = async () => {
  const planPath = planName.includes("/") ? path.resolve(planName) : path.resolve("src/plans", planName);
  const mod = (await import(pathToFileURL(planPath).href)) as Record<string, Plan>;
  const plan = Object.values(mod)[0];
  const lines = plan.scenes.map((s) => s.vo?.trim() ?? "");
  const chars = lines.reduce((n, l) => n + l.length, 0);
  const provider = pickProvider();
  const paid = provider === "elevenlabs" || provider === "openai";
  console.log(`${plan.slug}: ${lines.filter(Boolean).length} lines, ${chars} characters, provider=${provider}${paid ? " (PAID)" : " (free)"}`);
  if (dryRun) return;
  if (provider === "elevenlabs" && !voiceId) throw new Error("TTS_VOICE_ID is required for ElevenLabs");

  const dir = path.join("public", "vo", plan.slug);
  mkdirSync(dir, { recursive: true });
  const scenes: VoManifest["scenes"] = [];
  for (const [i, text] of lines.entries()) {
    if (!text) {
      scenes.push(null);
      continue;
    }
    const prev = lines.slice(0, i).filter(Boolean).slice(-1)[0];
    const next = lines.slice(i + 1).find(Boolean);
    const { audio, captions } =
      provider === "openai"
        ? await openai(text)
        : provider === "local"
          ? await local(text)
          : provider === "kokoro"
            ? await kokoro(text)
            : await elevenlabs(text, prev, next);
    const rel = `vo/${plan.slug}/scene-${String(i + 1).padStart(2, "0")}.mp3`;
    writeFileSync(path.join("public", rel), audio);
    const secs = await duration(path.join("public", rel));
    scenes.push({ file: rel, durationInSeconds: secs, captions: captions ?? evenCaptions(text, secs) });
    console.log(`scene ${i + 1}: ${secs.toFixed(2)}s`);
  }
  writeFileSync(path.join(dir, "manifest.json"), JSON.stringify({ provider, ai_voice: true, scenes }, null, 2));
  console.log(`Wrote ${dir}/manifest.json. Set voiceover: true in the plan.`);
};

main().catch((e: unknown) => {
  console.error(e instanceof Error ? e.message : e);
  process.exit(1);
});

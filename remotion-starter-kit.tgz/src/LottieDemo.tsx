import { Lottie, LottieAnimationData } from "@remotion/lottie";
import React, { useEffect, useState } from "react";
import { AbsoluteFill, cancelRender, continueRender, delayRender, staticFile } from "remotion";

// Minimal Lottie example: load JSON from public/ with delayRender so the frame waits for it.
// Remotion drives the Lottie frame from useCurrentFrame(), so it is frame-accurate.
export const LottieDemo: React.FC = () => {
  const [handle] = useState(() => delayRender("Loading Lottie"));
  const [data, setData] = useState<LottieAnimationData | null>(null);
  useEffect(() => {
    fetch(staticFile("lottie/pulse.json"))
      .then((r) => r.json())
      .then((json) => { setData(json); continueRender(handle); })
      .catch((err) => cancelRender(err));
  }, [handle]);
  return (
    <AbsoluteFill style={{ backgroundColor: "#0b0f1a", justifyContent: "center", alignItems: "center" }}>
      {data ? <Lottie animationData={data} loop style={{ width: 512, height: 512 }} /> : null}
    </AbsoluteFill>
  );
};

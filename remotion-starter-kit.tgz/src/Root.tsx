import React from "react";
import { Composition } from "remotion";
import { demoPlan } from "./plans/demo";
import { demoVoPlan } from "./plans/demoVo";
import { explainerPlan } from "./plans/explainer";
import { featureExplainerPlan } from "./plans/featureExplainer";
import { calculateSizzleMetadata } from "./Sizzle/calculateMetadata";
import { Sizzle } from "./Sizzle/Sizzle";
import { LottieDemo } from "./LottieDemo";

// Each plan renders in every aspect: <Name>-16x9, -9x16, -1x1. Add new plans here.
const PLANS = [
  { name: "Sizzle", plan: demoPlan },
  { name: "SizzleVo", plan: demoVoPlan },
  { name: "Explainer", plan: explainerPlan },
  { name: "FeatureExplainer", plan: featureExplainerPlan },
] as const;

// One component, several aspect ratios. Everything inside sizes off useLayout().
const ASPECTS = [
  { suffix: "16x9", width: 1920, height: 1080 },
  { suffix: "9x16", width: 1080, height: 1920 },
  { suffix: "1x1", width: 1080, height: 1080 },
] as const;

export const RemotionRoot: React.FC = () => (
  <>
    {PLANS.flatMap((p) =>
      ASPECTS.map((a) => (
        <Composition
          key={`${p.name}-${a.suffix}`}
          id={`${p.name}-${a.suffix}`}
          component={Sizzle}
          fps={30}
          width={a.width}
          height={a.height}
          durationInFrames={300} // replaced by calculateMetadata
          defaultProps={p.plan}
          calculateMetadata={calculateSizzleMetadata}
        />
      )),
    )}
    {/* Small Lottie example (public/lottie/pulse.json). */}
    <Composition id="LottieDemo" component={LottieDemo} fps={30} width={1920} height={1080} durationInFrames={120} />
  </>
);

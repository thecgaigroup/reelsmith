import React, { useState } from "react";
import { Audio } from "@remotion/media";
import { TransitionSeries, type TransitionPresentation } from "@remotion/transitions";
import { fade } from "@remotion/transitions/fade";
import { slide } from "@remotion/transitions/slide";
import { wipe } from "@remotion/transitions/wipe";
import { AbsoluteFill, interpolate, staticFile, useVideoConfig } from "remotion";
import { loadBrandFonts, themeFromBrand } from "../kit/brand";
import { FeatureCard, StatCallout } from "../kit/FeatureCard";
import { CaptionTrack } from "../kit/CaptionTrack";
import { GradientBg } from "../kit/GradientBg";
import { KineticText } from "../kit/KineticText";
import { useLayout } from "../kit/layout";
import { LogoReveal } from "../kit/LogoReveal";
import { LowerThird } from "../kit/LowerThird";
import { defaultTheme, type Theme } from "../kit/theme";
import type { Scene, SizzleProps, TransitionKind } from "../plans/types";
import { kindAt, timingFor, transitionFrames } from "./timing";


// Presentations have different prop types; widen them so one helper can return any.
type AnyPresentation = TransitionPresentation<Record<string, unknown>>;
const presentationFor = (kind: Exclude<TransitionKind, "none">, i: number): AnyPresentation => {
  if (kind === "slide") return slide({ direction: i % 2 ? "from-right" : "from-bottom" }) as AnyPresentation;
  if (kind === "wipe") return wipe({ direction: "from-left" }) as AnyPresentation;
  return fade() as AnyPresentation;
};

// Loops to fill any length; fades in/out and ducks to 35% only while VO is speaking.
// `volume` is a callback so ducking is per-frame (f = frame of the composition).
const MusicBed: React.FC<{ src: string; volume: number; speech: [number, number][] }> = ({ src, volume, speech }) => {
  const { durationInFrames, fps } = useVideoConfig();
  const ramp = Math.round(0.2 * fps);
  const duckAt = (f: number) =>
    speech.reduce((m, [a, b]) => {
      const d = interpolate(f, [a - ramp, a, b, b + ramp], [0, 1, 1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
      return Math.max(m, d);
    }, 0);
  return (
    <Audio
      src={staticFile(src)}
      loop
      loopVolumeCurveBehavior="extend" // volume callback gets composition frames, not per-loop frames
      volume={(f) =>
        interpolate(f, [0, 0.5 * fps, durationInFrames - 1.5 * fps, durationInFrames], [0, volume, volume, 0], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }) *
        (1 - 0.65 * duckAt(f))
      }
    />
  );
};

const SceneView: React.FC<{ scene: Scene; index: number; props: SizzleProps; theme: Theme }> = ({ scene, index, props, theme }) => {
  const { safeX } = useLayout();
  return (
    <AbsoluteFill>
      <GradientBg theme={theme} seed={index} />
      <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: `0 ${safeX}px` }}>
        {scene.kind === "kinetic" ? <KineticText text={scene.text} theme={theme} /> : null}
        {scene.kind === "logo" ? <LogoReveal theme={theme} logoFile={theme.logo} wordmark={props.wordmark} tagline={props.tagline} /> : null}
        {scene.kind === "feature" ? <FeatureCard theme={theme} index={scene.index} title={scene.text} body={scene.sub} /> : null}
        {scene.kind === "stat" ? <StatCallout theme={theme} value={scene.value ?? scene.text} label={scene.sub} /> : null}
      </AbsoluteFill>
      {scene.kind === "lowerThird" ? (
        <>
          <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: `0 ${safeX}px` }}>
            <KineticText text={scene.text} theme={theme} size={100} />
          </AbsoluteFill>
          <LowerThird theme={theme} title={scene.text} subtitle={scene.sub} raised={Boolean(props.vo?.[index])} />
        </>
      ) : null}
      {props.vo?.[index] ? (
        <>
          <Audio src={staticFile(props.vo[index]!.file)} />
          <CaptionTrack captions={props.vo[index]!.captions} theme={theme} />
        </>
      ) : null}
    </AbsoluteFill>
  );
};

// [start, end] composition frames where each VO clip plays (scene i starts at the sum of earlier scenes).
const speechWindows = (props: SizzleProps, sceneFrames: number[]): [number, number][] => {
  let start = 0;
  return sceneFrames.flatMap((len, i) => {
    const s = start;
    start += len;
    const vf = props.voFrames?.[i] ?? 0;
    return vf ? [[s, s + vf] as [number, number]] : [];
  });
};

// Platforms increasingly expect synthetic-voice disclosure; keep it small, inside the safe area, on for the whole video.
const AiVoiceLabel: React.FC<{ theme: Theme; label?: string }> = ({ theme, label }) => {
  const { unit, safeX, safeY } = useLayout();
  return (
    <div style={{ position: "absolute", left: safeX, top: safeY * 0.5, fontFamily: theme.fontFamily, fontSize: 22 * unit,
                  color: theme.fg, opacity: 0.6, letterSpacing: "0.02em" }}>
      {label ?? "Narration: AI-generated voice"}
    </div>
  );
};

export const Sizzle: React.FC<SizzleProps> = (props) => {
  const { fps } = useVideoConfig();
  const theme = themeFromBrand(props.brand, defaultTheme);
  useState(() => loadBrandFonts(props.brand)); // once per mount
  const sceneFrames = props.sceneFrames ?? props.scenes.map(() => 60);
  const t = transitionFrames(props, fps);
  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg }}>
      <TransitionSeries>
        {props.scenes.map((scene, i) => {
          const next = i + 1 < props.scenes.length ? kindAt(props, i + 1) : "none";
          const items = [];
          if (i > 0) {
            const kind = kindAt(props, i);
            if (kind !== "none") {
              items.push(
                <TransitionSeries.Transition
                  key={`t${i}`}
                  presentation={presentationFor(kind, i)}
                  timing={timingFor(props, fps)}
                />,
              );
            }
          }
          items.push(
            <TransitionSeries.Sequence
              key={`s${i}`}
              name={`Scene ${i + 1}`}
              // add the outgoing transition so the next cut stays on the beat grid
              durationInFrames={sceneFrames[i] + (next === "none" ? 0 : t)}
            >
              <SceneView scene={scene} index={i} props={props} theme={theme} />
            </TransitionSeries.Sequence>,
          );
          return items;
        })}
      </TransitionSeries>
      {props.vo?.some(Boolean) && props.aiVoiceDisclosure !== false ? (
        <AiVoiceLabel theme={theme} label={typeof props.aiVoiceDisclosure === "string" ? props.aiVoiceDisclosure : undefined} />
      ) : null}
      {props.music ? <MusicBed src={props.music} volume={props.musicVolume} speech={speechWindows(props, sceneFrames)} /> : null}
    </AbsoluteFill>
  );
};

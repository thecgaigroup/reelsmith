import { ALL_FORMATS, Input, UrlSource } from "mediabunny";
import { CalculateMetadataFunction, staticFile } from "remotion";
import type { SizzleProps, VoManifest } from "../plans/types";
import { framesPerBeat } from "./timing";

const PAD_SECONDS = 0.4; // breathing room after each voiceover line

const audioSeconds = async (file: string) => {
  const input = new Input({ formats: ALL_FORMATS, source: new UrlSource(staticFile(file)) });
  try {
    return await input.computeDuration();
  } finally {
    input.dispose();
  }
};

// Scene length = max(planned beats, voiceover + pad) rounded UP to whole beats.
// Each outgoing transition is added to its scene in the component, so the
// total is simply the sum of scene frames and every cut lands on a beat.
export const calculateSizzleMetadata: CalculateMetadataFunction<SizzleProps> = async ({ props }) => {
  const fps = 30;
  const fpb = framesPerBeat(props.bpm, fps);
  let brand = props.brand;
  if (props.brandFile && !brand) {
    const r = await fetch(staticFile(props.brandFile));
    if (r.ok) brand = await r.json();
    else console.warn(`Brand file ${props.brandFile} not found under public/; using the default theme.`);
  }
  let vo: VoManifest["scenes"] | undefined;
  if (props.voiceover) {
    const res = await fetch(staticFile(`vo/${props.slug}/manifest.json`));
    if (res.ok) {
      vo = ((await res.json()) as VoManifest).scenes;
    } else {
      // No voiceover generated yet: fall back to the planned beats (silent) so
      // `remotion compositions` and draft renders still work from a fresh kit.
      console.warn(`Voiceover manifest missing for ${props.slug}; rendering without VO. Run scripts/generate-voiceover.ts first.`);
    }
  }
  const voFrames = await Promise.all(
    props.scenes.map(async (_, i) => (vo?.[i] ? Math.ceil((await audioSeconds(vo[i]!.file)) * fps) : 0)),
  );
  const sceneFrames = props.scenes.map((scene, i) => {
    const planned = scene.beats * fpb;
    if (!voFrames[i]) return Math.round(planned);
    const needed = voFrames[i] + PAD_SECONDS * fps;
    return Math.round(Math.max(planned, Math.ceil(needed / fpb) * fpb));
  });
  return {
    fps,
    durationInFrames: sceneFrames.reduce((a, b) => a + b, 0),
    props: { ...props, brand, sceneFrames, vo, voFrames },
  };
};

import { linearTiming } from "@remotion/transitions";
import type { Plan, TransitionKind } from "../plans/types";

export const framesPerBeat = (bpm: number, fps: number) => (60 / bpm) * fps;

// Transition length: half a beat, rounded.
export const transitionFrames = (plan: Plan, fps: number) =>
  Math.max(1, Math.round(framesPerBeat(plan.bpm, fps) / 2));

export const timingFor = (plan: Plan, fps: number) =>
  linearTiming({ durationInFrames: transitionFrames(plan, fps) });

export const kindAt = (plan: Plan, i: number): TransitionKind =>
  i === 0 ? "none" : (plan.scenes[i].transitionIn ?? "fade");

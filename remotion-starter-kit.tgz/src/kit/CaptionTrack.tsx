import React from "react";
import { useCurrentFrame, useVideoConfig } from "remotion";
import { useLayout } from "./layout";
import type { Theme } from "./theme";

// Same shape as @remotion/captions' Caption, so either source works.
export type Caption = { text: string; startMs: number; endMs: number };

// Burned-in captions; highlights the word being spoken. Times are relative to
// the Sequence this is placed in.
// Split into pages of at most `max` words, preferring breaks after , . ; : ! ?
const paginate = (captions: Caption[], max: number) => {
  const pages: number[] = []; // start index of each page
  let start = 0;
  captions.forEach((c, i) => {
    const len = i - start + 1;
    if (len >= max || (len >= 2 && /[,.;:!?]$/.test(c.text))) {
      pages.push(start);
      start = i + 1;
    }
  });
  if (start < captions.length) pages.push(start);
  return pages;
};

export const CaptionTrack: React.FC<{ captions: Caption[]; theme: Theme; windowSize?: number }> = ({
  captions,
  theme,
  windowSize,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { unit, safeX, safeY, orientation } = useLayout();
  const vertical = orientation === "vertical";
  const max = windowSize ?? (vertical ? 4 : 6);
  const ms = (frame / fps) * 1000;
  // Alignment leaves gaps between words (spaces, pauses); keep the last started
  // word lit through them so captions don't blink, and clear after real silence.
  let idx = -1;
  for (let i = 0; i < captions.length && captions[i].startMs <= ms; i++) idx = i;
  if (idx === -1 || ms > captions[idx].endMs + 600) return null;
  const starts = paginate(captions, max);
  const start = starts.filter((s) => s <= idx).slice(-1)[0] ?? 0;
  const end = starts.find((s) => s > idx) ?? captions.length;
  const page = captions.slice(start, end);
  return (
    <div
      style={{
        position: "absolute",
        left: safeX,
        right: safeX,
        bottom: safeY,
        textAlign: "center",
        fontFamily: theme.fontFamily,
        fontWeight: 800,
        fontSize: (vertical ? 68 : 56) * unit,
        lineHeight: 1.15,
        color: theme.fg,
        textShadow: "0 4px 20px rgba(0,0,0,0.6)",
      }}
    >
      {page.map((c, i) => (
        <span key={i} style={{ color: start + i === idx ? theme.accents[2] : undefined }}>
          {c.text}{" "}
        </span>
      ))}
    </div>
  );
};

import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { useLayout } from "./layout";
import { stripMarkup, type Theme } from "./theme";

// Numbered feature card: chip + title + body, spring entrance (damping ~16, 12-15 frame stagger) and a slow push-in.
export const FeatureCard: React.FC<{ theme: Theme; index?: number; title: string; body?: string }> = ({ theme, index, title, body }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const { unit, orientation } = useLayout();
  const p = (d: number) => spring({ frame: frame - d, fps, config: { damping: 16 } });
  const push = interpolate(frame, [0, durationInFrames], [1, 1.04]);
  const out = interpolate(frame, [durationInFrames - 8, durationInFrames], [1, 0], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const w = orientation === "landscape" ? 1100 : 880;
  return (
    <div style={{ width: w * unit, scale: String(push), opacity: out, display: "flex", flexDirection: "column", gap: 26 * unit,
                  padding: 56 * unit, borderRadius: 36 * unit, background: theme.surface ?? "rgba(255,255,255,0.06)",
                  border: `${2 * unit}px solid rgba(255,255,255,0.10)`, boxShadow: `0 ${30 * unit}px ${80 * unit}px rgba(0,0,0,0.35)`,
                  translate: `0 ${(1 - p(0)) * 80 * unit}px`, fontFamily: theme.fontFamily, color: theme.fg }}>
      {index !== undefined ? (
        <div style={{ alignSelf: "flex-start", opacity: p(12), scale: String(0.6 + 0.4 * p(12)), padding: `${10 * unit}px ${26 * unit}px`, borderRadius: 999,
                      background: theme.accents[0], fontFamily: theme.headingFamily ?? theme.fontFamily, fontWeight: 700, fontSize: 34 * unit }}>
          {String(index).padStart(2, "0")}
        </div>
      ) : null}
      <div style={{ fontFamily: theme.headingFamily ?? theme.fontFamily, fontWeight: 700, fontSize: 84 * unit, lineHeight: 1.05, opacity: p(18),
                    translate: `0 ${(1 - p(18)) * 30 * unit}px` }}>{stripMarkup(title)}</div>
      {body ? <div style={{ fontSize: 44 * unit, lineHeight: 1.3, color: theme.muted ?? theme.fg, opacity: p(30) }}>{body}</div> : null}
      <div style={{ height: 8 * unit, borderRadius: 8 * unit, width: `${interpolate(p(24), [0, 1], [0, 40])}%`,
                    background: `linear-gradient(90deg, ${theme.accents[0]}, ${theme.accents[1]})` }} />
    </div>
  );
};

// Big stat: value springs in, label follows. Keep a source line in the plan's sub text.
export const StatCallout: React.FC<{ theme: Theme; value: string; label?: string }> = ({ theme, value, label }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const { unit } = useLayout();
  const s = spring({ frame, fps, config: { damping: 14 } });
  const l = spring({ frame: frame - 14, fps, config: { damping: 200 } });
  const grow = interpolate(frame, [0, durationInFrames], [1, 1.06]);
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 20 * unit, textAlign: "center" }}>
      <div style={{ fontFamily: theme.headingFamily ?? theme.fontFamily, fontWeight: 700, fontSize: 300 * unit, lineHeight: 1,
                    color: theme.accents[1], scale: String((0.5 + 0.5 * s) * grow), opacity: s }}>{value}</div>
      {label ? <div style={{ fontFamily: theme.fontFamily, fontSize: 56 * unit, color: theme.fg, opacity: l, translate: `0 ${(1 - l) * 30 * unit}px` }}>{label}</div> : null}
    </div>
  );
};

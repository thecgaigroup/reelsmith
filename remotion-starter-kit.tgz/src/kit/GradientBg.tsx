import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import type { Theme } from "./theme";

export const GradientBg: React.FC<{ theme: Theme; seed?: number }> = ({
  theme,
  seed = 0,
}) => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = (frame + seed * 37) / 30;
  const drift = interpolate(frame, [0, durationInFrames], [0, 40]);
  const [a, b, c] = theme.accents;
  return (
    <AbsoluteFill style={{ backgroundColor: theme.bg, overflow: "hidden" }}>
      <AbsoluteFill
        style={{
          background: `radial-gradient(circle at ${30 + Math.sin(t * 0.6) * 15}% ${35 + Math.cos(t * 0.5) * 15}%, ${a}cc 0%, transparent 45%),
            radial-gradient(circle at ${70 + Math.cos(t * 0.4) * 15}% ${65 + Math.sin(t * 0.7) * 12}%, ${b}aa 0%, transparent 50%),
            radial-gradient(circle at ${50 + drift / 4}% ${90 - drift / 3}%, ${c}66 0%, transparent 40%)`,
          filter: "blur(40px)",
          scale: "1.2",
        }}
      />
      <AbsoluteFill
        style={{ background: "radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.65) 100%)" }}
      />
    </AbsoluteFill>
  );
};

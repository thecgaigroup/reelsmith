import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { useLayout } from "./layout";
import type { Theme } from "./theme";

// Word-by-word spring reveal. Text wrapped in *asterisks* (one or more words) gets the accent color.
export const KineticText: React.FC<{
  text: string;
  theme: Theme;
  size?: number; // px at 1080 short edge
  staggerFrames?: number;
  delay?: number;
  align?: "center" | "left";
}> = ({ text, theme, size = 120, staggerFrames = 3, delay = 0, align = "center" }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const { unit } = useLayout();
  // *accent spans* may cover several words: toggle on each asterisk.
  let on = false;
  const words = text.split(" ").filter(Boolean).map((raw) => {
    const opens = raw.startsWith("*");
    const closes = raw.length > 1 && raw.endsWith("*");
    if (opens) on = true;
    const accent = on;
    if (closes || (opens && raw.length === 1)) on = false;
    return { word: raw.replace(/\*/g, ""), accent };
  });
  const exit = interpolate(frame, [durationInFrames - 8, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <div
      style={{
        fontFamily: theme.headingFamily ?? theme.fontFamily,
        fontWeight: 700,
        fontSize: size * unit,
        lineHeight: 1.05,
        letterSpacing: "-0.03em",
        color: theme.fg,
        textAlign: align,
        display: "flex",
        flexWrap: "wrap",
        justifyContent: align === "center" ? "center" : "flex-start",
        gap: `0 ${0.28 * size * unit}px`,
        opacity: exit,
      }}
    >
      {words.map(({ word, accent }, i) => {
        const p = spring({ frame: frame - delay - i * staggerFrames, fps, config: { damping: 14, mass: 0.6 } });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              color: accent ? theme.accents[2] : undefined,
              opacity: p,
              translate: `0 ${(1 - p) * 60 * unit}px`,
              scale: String(0.85 + 0.15 * p),
            }}
          >
            {word}
          </span>
        );
      })}
    </div>
  );
};

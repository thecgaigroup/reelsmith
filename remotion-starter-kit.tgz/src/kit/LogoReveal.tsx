import React from "react";
import { Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { useLayout } from "./layout";
import type { Theme } from "./theme";

// Pass logoFile (relative to public/) for an image logo, or wordmark for text.
export const LogoReveal: React.FC<{ theme: Theme; logoFile?: string; wordmark?: string; tagline?: string }> = ({
  theme,
  logoFile,
  wordmark,
  tagline,
}) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { unit } = useLayout();
  const s = spring({ frame, fps, config: { damping: 12 } });
  const wipe = interpolate(frame, [6, 26], [0, 100], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const tag = spring({ frame: frame - 18, fps, config: { damping: 200 } });
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 28 * unit }}>
      <div style={{ scale: String(0.6 + 0.4 * s), opacity: s }}>
        {logoFile ? (
          <Img src={staticFile(logoFile)} style={{ height: 220 * unit }} />
        ) : (
          <div
            style={{
              fontFamily: theme.headingFamily ?? theme.fontFamily,
              fontWeight: 700,
              fontSize: 150 * unit,
              letterSpacing: "-0.04em",
              color: theme.fg,
              clipPath: `inset(0 ${100 - wipe}% 0 0)`,
            }}
          >
            {wordmark}
          </div>
        )}
      </div>
      {tagline ? (
        <div
          style={{
            fontFamily: theme.fontFamily,
            fontWeight: 400,
            fontSize: 44 * unit,
            color: theme.fg,
            opacity: tag * 0.85,
            translate: `0 ${(1 - tag) * 20 * unit}px`,
          }}
        >
          {tagline}
        </div>
      ) : null}
    </div>
  );
};

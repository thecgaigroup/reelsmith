import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { useLayout } from "./layout";
import { stripMarkup, type Theme } from "./theme";

export const LowerThird: React.FC<{ theme: Theme; title: string; subtitle?: string; raised?: boolean }> = ({ theme, title, subtitle, raised = false }) => {
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const { unit, safeX, safeY } = useLayout();
  const inP = spring({ frame, fps, config: { damping: 200 } });
  const out = interpolate(frame, [durationInFrames - 10, durationInFrames], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  return (
    <div
      style={{
        position: "absolute",
        left: safeX,
        bottom: raised ? safeY + 170 * unit : safeY, // raised: leave room for captions
        opacity: out,
        translate: `${(1 - inP) * -40 * unit}px 0`,
        borderLeft: `${8 * unit}px solid ${theme.accents[2]}`,
        paddingLeft: 24 * unit,
        fontFamily: theme.fontFamily,
        color: theme.fg,
      }}
    >
      <div style={{ fontWeight: 800, fontSize: 52 * unit }}>{stripMarkup(title)}</div>
      {subtitle ? <div style={{ fontWeight: 400, fontSize: 34 * unit, opacity: 0.8 }}>{subtitle}</div> : null}
    </div>
  );
};

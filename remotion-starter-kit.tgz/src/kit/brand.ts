import { continueRender, delayRender, staticFile } from "remotion";
import type { Theme } from "./theme";

// Shape of brand/brand.resolved.json written by `python3 scripts/brand.py bundle BRAND --out public`
// (Reelsmith's brand kit). Paths are relative to public/.
export type BrandFont = { family: string; weight?: number; file?: string };
export type BrandKit = {
  name: string;
  colors: Partial<Record<"bg" | "fg" | "primary" | "secondary" | "accent" | "muted" | "surface", string>>;
  fonts?: { heading?: BrandFont; body?: BrandFont };
  logo?: { primary?: string; mark?: string; on_dark?: string };
  voice?: { cta?: string; tagline?: string };
};

export const themeFromBrand = (b: BrandKit | undefined, fallback: Theme): Theme => {
  if (!b) return fallback;
  const c = b.colors ?? {};
  const fam = (f?: BrandFont) => (f?.family ? `"${f.family}", ${fallback.fontFamily}` : undefined);
  return {
    bg: c.bg ?? fallback.bg,
    fg: c.fg ?? fallback.fg,
    accents: [c.primary ?? fallback.accents[0], c.secondary ?? fallback.accents[1], c.accent ?? fallback.accents[2]],
    fontFamily: fam(b.fonts?.body) ?? fallback.fontFamily,
    headingFamily: fam(b.fonts?.heading) ?? fam(b.fonts?.body) ?? fallback.fontFamily,
    muted: c.muted,
    surface: c.surface,
    logo: b.logo?.on_dark ?? b.logo?.primary,
  };
};

// Load bundled brand fonts once; delayRender blocks frames until they are ready (no fallback-font flashes).
const loaded = new Set<string>();
export const loadBrandFonts = (b?: BrandKit) => {
  for (const f of [b?.fonts?.heading, b?.fonts?.body]) {
    if (!f?.file || loaded.has(f.file) || typeof FontFace === "undefined") continue;
    loaded.add(f.file);
    const handle = delayRender(`brand font ${f.family}`);
    new FontFace(f.family, `url("${staticFile(f.file)}")`, { weight: "100 900" })
      .load()
      .then((face) => {
        document.fonts.add(face);
        continueRender(handle);
      })
      .catch(() => continueRender(handle)); // missing font: render with the fallback instead of hanging
  }
};

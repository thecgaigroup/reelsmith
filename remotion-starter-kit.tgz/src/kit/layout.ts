import { useVideoConfig } from "remotion";

// One component tree, many aspect ratios: size everything off the short edge.
export const useLayout = () => {
  const { width, height } = useVideoConfig();
  const unit = Math.min(width, height) / 1080; // 1 at 1080p, any aspect
  const orientation =
    height > width ? "vertical" : height === width ? "square" : "landscape";
  // Keep text inside platform-safe areas (vertical UIs cover top/bottom).
  const safeX = width * (orientation === "vertical" ? 0.08 : 0.07);
  const safeY = height * (orientation === "vertical" ? 0.14 : 0.08);
  return { width, height, unit, orientation, safeX, safeY } as const;
};

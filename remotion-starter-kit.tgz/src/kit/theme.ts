import { loadFont as loadDisplay } from "@remotion/google-fonts/Inter";

// Load only the weights/subsets you use; loadFont blocks rendering until ready.
const { fontFamily } = loadDisplay("normal", {
  weights: ["400", "800"],
  subsets: ["latin"],
});

export type Theme = {
  bg: string;
  fg: string;
  accents: [string, string, string];
  fontFamily: string;
  headingFamily?: string; // brand heading font (falls back to fontFamily)
  muted?: string;
  surface?: string;
  logo?: string; // path under public/, e.g. brand/logo.svg
};

export const defaultTheme: Theme = {
  bg: "#07060f",
  fg: "#ffffff",
  accents: ["#7c3aed", "#2563eb", "#10b981"],
  fontFamily,
};

// Remove *accent* markup for places that render plain text (lower thirds, captions, titles).
export const stripMarkup = (text: string) => text.replace(/\*/g, "");

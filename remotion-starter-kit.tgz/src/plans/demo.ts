import type { Plan } from "./types";

export const demoPlan: Plan = {
  slug: "demo",
  bpm: 120,
  music: "music/demo-bed-120bpm.mp3",
  musicVolume: 0.8,
  voiceover: false,
  wordmark: "Northwind",
  tagline: "Ship video like code.",
  scenes: [
    { kind: "kinetic", text: "Your story. *Faster.*", beats: 4, vo: "Your story, told faster." },
    { kind: "kinetic", text: "Every frame *on brand*", beats: 4, transitionIn: "slide", vo: "Every frame, on brand." },
    { kind: "lowerThird", text: "Built with React", sub: "Rendered on autopilot", beats: 4, transitionIn: "wipe", vo: "Built with React and rendered on autopilot." },
    { kind: "kinetic", text: "16:9. 9:16. *One source.*", beats: 4, transitionIn: "fade", vo: "Every aspect ratio from one source." },
    { kind: "logo", text: "", beats: 8, transitionIn: "fade", vo: "Northwind. Ship video like code." },
  ],
};

import { demoPlan } from "./demo";
import type { Plan } from "./types";

// Same reel, narrated. Run generate-voiceover.ts demoVo first.
export const demoVoPlan: Plan = { ...demoPlan, slug: "demo-vo", voiceover: true };

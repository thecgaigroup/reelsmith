import type { Plan } from "./types";

// Narrated explainer, ~35s. Generate VO first:
//   TTS_PROVIDER=elevenlabs npx tsx scripts/generate-voiceover.ts src/plans/explainer.ts --dry-run
export const explainerPlan: Plan = {
  slug: "explainer",
  bpm: 120,
  music: "music/demo-bed-120bpm.mp3",
  musicVolume: 0.6,
  voiceover: true,
  wordmark: "Remotion Video Maker",
  tagline: "Any topic. Any aspect ratio.",
  scenes: [
    {
      kind: "kinetic",
      text: "Start with a *topic*",
      beats: 8,
      vo: "Give Remotion Video Maker a topic, a product, or an idea, and it writes a short script and shot list for you to approve.",
    },
    {
      kind: "kinetic",
      text: "Scenes built in *code*",
      beats: 8,
      transitionIn: "slide",
      vo: "Every scene is built in React, so type, motion, and brand colors stay consistent from the first frame to the last.",
    },
    {
      kind: "lowerThird",
      text: "Narrated and *captioned*",
      sub: "Word-timed from the voiceover",
      beats: 8,
      transitionIn: "wipe",
      vo: "A natural voiceover is generated for each scene, and captions are timed to every spoken word.",
    },
    {
      kind: "kinetic",
      text: "16:9. 9:16. *1:1.*",
      beats: 8,
      transitionIn: "fade",
      vo: "The same video renders in widescreen, vertical, or square, ready for any channel.",
    },
    {
      kind: "logo",
      text: "",
      beats: 8,
      transitionIn: "fade",
      vo: "Remotion Video Maker. From a topic to a finished video.",
    },
  ],
};

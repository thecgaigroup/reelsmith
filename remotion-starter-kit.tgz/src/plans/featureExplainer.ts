import type { Plan } from "./types";

// Branded feature explainer (~30-40s): hook -> 3 numbered features -> proof stat -> logo + CTA.
// Uses the Reelsmith brand kit: `python3 <reelsmith>/scripts/brand.py bundle BRAND.json --out public`
// writes public/brand/brand.resolved.json (colors, fonts, logo). Without it the default theme is used.
// Free VO: npx tsx scripts/generate-voiceover.ts src/plans/featureExplainer.ts   (auto = Kokoro, else espeak)
export const featureExplainerPlan: Plan = {
  slug: "feature-explainer",
  bpm: 120,
  music: "music/demo-bed-120bpm.mp3",
  musicVolume: 0.5,
  voiceover: true,
  brandFile: "brand/brand.resolved.json",
  wordmark: "Brightline",
  tagline: "Ideas, shipped faster.",
  scenes: [
    { kind: "kinetic", text: "Reports take *days.*", beats: 6,
      vo: "Your weekly report shouldn't take three days to build." },
    { kind: "feature", index: 1, text: "Connect once", sub: "Pull from the tools you already use.", beats: 8, transitionIn: "slide",
      vo: "Connect your tools once, and Brightline keeps the numbers fresh." },
    { kind: "feature", index: 2, text: "Ask in plain words", sub: "Type a question, get a chart.", beats: 8, transitionIn: "slide",
      vo: "Ask a question in plain words, and get a chart back in seconds." },
    { kind: "feature", index: 3, text: "Share in one click", sub: "Live links, not stale slides.", beats: 8, transitionIn: "slide",
      vo: "Share a live link instead of another stale slide deck." },
    { kind: "stat", text: "4x", value: "4x", sub: "faster weekly reporting (sample figure)", beats: 6, transitionIn: "wipe",
      vo: "Teams in our sample saw reporting get four times faster." },
    { kind: "logo", text: "", beats: 8, transitionIn: "fade",
      vo: "Brightline. Start free today." },
  ],
};

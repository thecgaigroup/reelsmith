import type { BrandKit } from "../kit/brand";
import type { Caption } from "../kit/CaptionTrack";

export type TransitionKind = "fade" | "slide" | "wipe" | "none";

export type Scene = {
  kind: "kinetic" | "logo" | "lowerThird" | "feature" | "stat";
  text: string; // on-screen text; wrap a word in *asterisks* to accent it
  sub?: string; // subtitle / feature body / stat label
  index?: number; // feature number chip (feature scenes)
  value?: string; // big number (stat scenes)
  beats: number; // minimum length in musical beats
  vo?: string; // voiceover line for this scene (optional)
  transitionIn?: TransitionKind; // transition from the previous scene
};

export type Plan = {
  slug: string;
  bpm: number; // tempo of the music bed; scene cuts land on beats
  music?: string; // path under public/, user-supplied or licensed
  musicVolume: number;
  voiceover: boolean; // true once public/vo/<slug>/manifest.json exists
  wordmark: string;
  tagline?: string;
  brandFile?: string; // e.g. "brand/brand.resolved.json" under public/ (Reelsmith brand kit); loaded in calculateMetadata
  brand?: BrandKit; // resolved at render time
  aiVoiceDisclosure?: boolean | string; // default true: small "Narration: AI-generated voice" label when VO plays
  scenes: Scene[];
};

export type VoManifest = {
  provider?: string;
  ai_voice?: boolean;
  scenes: ({ file: string; durationInSeconds?: number; captions: Caption[] } | null)[];
};

// Props after calculateMetadata has resolved timing.
export type SizzleProps = Plan & {
  sceneFrames?: number[];
  vo?: VoManifest["scenes"];
  voFrames?: number[]; // measured VO length per scene, for ducking
};
